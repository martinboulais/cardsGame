$(document ).ready(function(){
   
	
	
	   var xhr = new XMLHttpRequest()
	   xhr.open("GET", '/cards',true);
	   xhr.onreadystatechange = function() {
	        if (xhr.readyState == 4 && (xhr.status == 200 || xhr.status == 0)) {
	        	
	        	console.log(xhr.responseText);
	        	
	        	var data = JSON.parse(xhr.responseText);
	        	
	        	for(i=0;i<data.length;i++){
	                //console.log(data[i].name);
	        	// si la carte est à vendre	
	         
	          fillCurrentCard(data[i].imgUrl,data[i].family,data[i].imgUrl,data[i].name,data[i].description,data[i].hp,data[i].energy,data[i].attack,data[i].defence);
	          addCardToList(data[i].imgUrl,data[i].family,data[i].imgUrl,data[i].name,data[i].description,data[i].hp,data[i].energy,data[i].attack,data[i].defence,data[i].price);

	            	               console.log("oui");
	          
	               
	            }
	        }
	    };
	    xhr.send();
    
    
    
});




function fillCurrentCard(imgUrlFamily,familyName,imgUrl,name,description,hp,energy,attack,defence,price){
    //FILL THE CURRENT CARD
    $('#cardFamilyImgId')[0].src=imgUrlFamily;
    $('#cardFamilyNameId')[0].innerText=familyName;
    $('#cardImgId')[0].src=imgUrl;
    $('#cardNameId')[0].innerText=name;
    $('#cardDescriptionId')[0].innerText=description;
    $('#cardHPId')[0].innerText=hp+" HP";
    $('#cardEnergyId')[0].innerText=energy+" Energy";
    $('#cardAttackId')[0].innerText=attack+" Attack";
    $('#cardDefenceId')[0].innerText=defence+" Defence";
    $('#cardPriceId')[0].innerText=price+" $";
};


function addCardToList(imgUrlFamily,familyName,imgUrl,name,description,hp,energy,attack,defence,price){
    
    content="\
    <td> \
    <img  class='ui avatar image' src='"+imgUrl+"'> <span>"+name+" </span> \
   </td> \
    <td>"+description+"</td> \
    <td>"+familyName+"</td> \
    <td>"+hp+"</td> \
    <td>"+energy+"</td> \
    <td>"+attack+"</td> \
    <td>"+defence+"</td> \
    <td>"+price+"$</td>\
    <td>\
        <div class='ui vertical animated button' tabindex='0'>\
            <div class='hidden content'>Sell</div>\
    <div class='visible content'>\
        <i class='shop icon'></i>\
    </div>\
    </div>\
    </td>";
    
    $('#cardListId tr:last').after('<tr>'+content+'</tr>');
    
    
};