package com.cpe.cards;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.cpe.cards.controller.CardsRepository;


@SpringBootApplication
public class CardsApplication {

	@Autowired
    private CardsRepository cardRepository;

 
	
	public static void main(String[] args) {
		SpringApplication.run(CardsApplication.class, args);
	}
}
