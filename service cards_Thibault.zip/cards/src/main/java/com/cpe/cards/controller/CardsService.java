package com.cpe.cards.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cpe.cards.model.Card;

@Service
public class CardsService {

	@Autowired
	private CardsRepository cardsRepository;

	public List<Card> getAllCards() {
		List<Card> cards = new ArrayList<>();
		cardsRepository.findAll().forEach(cards::add);
		return cards;
	}

	public Card getCardByName(String name) {
		List<Card> cardList=new ArrayList<Card>();
		cardList=cardsRepository.findByName(name);
		/*for (i )
		name.equals(carList[nom])*/
		System.out.println("liste carte"+cardList);
		return cardList.get(1);
	}

	public void addCard(Card card) {
		cardsRepository.save(card);
	}

	public void updateCard(Card card) {
		cardsRepository.save(card);

	}

	public void deleteCard(Integer id) {
		cardsRepository.delete(id);
	}

	public Card getCardbyid(int id) {
		// TODO Auto-generated method stub
		return cardsRepository.findOne(id);
	}

	

}
