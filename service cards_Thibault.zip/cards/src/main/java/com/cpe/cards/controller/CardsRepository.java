package com.cpe.cards.controller;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.cpe.cards.model.Card;

public interface CardsRepository extends CrudRepository<Card, Integer> {

	public List<Card> findByName(String name);
	
	public Card findOne(Integer id);

}
