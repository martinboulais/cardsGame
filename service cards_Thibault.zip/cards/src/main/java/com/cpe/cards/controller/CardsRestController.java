package com.cpe.cards.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cpe.cards.model.Card;

@RestController
public class CardsRestController {
	
	@Autowired
	private CardsService CardsService;
	
	@RequestMapping("/test")
	private String test() {
		return "test";

	}
	/**
	 * 
	 * @return envoie toutes les cartes en json
	 */
	@RequestMapping("/cards")
	private List<Card> getAllCards() {
		return CardsService.getAllCards();

	}
	
	/**
	 * 
	 * @param name
	 * @return marche pas encore
	 */
	@RequestMapping("/card/name/{name}")
	private Card getCardbyname(@PathVariable String name) {
		/*
		try
		{
			b = Integer.valueOf(name);		
			System.out.println(name);

		}
		catch (Exception name)
		{
			b = 1;
		}*/
		
		return CardsService.getCardByName(name);
		}
	/**
	 * 
	 * @param id
	 * @return la carte
	 */
	@RequestMapping("/card/{id}")
	private Card getCard(@PathVariable Integer id) {
	return CardsService.getCardbyid(id);
	}
	/**
	 * ajout d'une carte
	 * @param card
	 */
	@RequestMapping(method=RequestMethod.POST,value="/cards")
	public void addCard(@RequestBody Card card) {
		CardsService.addCard(card);
	}
	/**
	 *  modifie une carte
	 * @param card
	 * @param id
	 */
	@RequestMapping(method=RequestMethod.PUT,value="/update_card/{id}")
	public void updateCard(@RequestBody Card card,@PathVariable  Integer id) {
		card.setId(id);
		CardsService.updateCard(card);
	}
	
	@RequestMapping(method=RequestMethod.DELETE,value="/delete_card/{id}")
	public void deleteCard(@PathVariable Integer id) {
		CardsService.deleteCard(id);
	}
	
	
	

}
