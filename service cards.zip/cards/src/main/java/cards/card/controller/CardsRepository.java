package cards.card.controller;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import cards.card.model.Card;

public interface CardsRepository extends CrudRepository<Card, Integer> {

	public List<Card> findByName(String name);
	
	public Card findOne(Integer id);

}
